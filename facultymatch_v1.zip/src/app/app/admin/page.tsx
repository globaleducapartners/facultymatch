import { redirect } from 'next/navigation';
export default function OldAdminPage() {
  redirect('/control');
}
