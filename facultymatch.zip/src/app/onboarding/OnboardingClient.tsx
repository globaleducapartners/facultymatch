"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import Link from "next/link";
import { autosaveOnboarding, saveOnboarding } from "@/app/auth/actions";
import {
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Globe,
  Target,
  FileText,
  Eye,
  Loader2,
  Plus,
  Trash2,
  Languages,
  GraduationCap,
  History,
  Linkedin,
  MapPin,
  Sparkles,
  UserCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/ui/Logo";
import { motion, AnimatePresence } from "framer-motion";
import { useForm, useFieldArray } from "react-hook-form";
import { toast } from "sonner";

const LANGUAGES_OPTIONS = [
  { label: "Español", value: "ES" },
  { label: "Inglés", value: "EN" },
  { label: "Francés", value: "FR" },
  { label: "Portugués", value: "PT" },
  { label: "Italiano", value: "IT" },
  { label: "Alemán", value: "DE" },
  { label: "Chino", value: "ZH" },
  { label: "Otro", value: "OTHER" },
];

const AREAS = [
  "Business & Management",
  "Ingeniería & Tecnología",
  "Ciencias de la Salud",
  "Derecho & Política",
  "Educación",
  "Artes & Humanidades",
  "Ciencias Sociales",
  "Ciencias Naturales",
  "Inteligencia Artificial",
  "Sostenibilidad",
  "Economía",
  "Psicología",
];

const MODALITIES = [
  { id: "Presencial", label: "Presencial" },
  { id: "Online", label: "Online" },
  { id: "Híbrida", label: "Híbrida" },
];

interface OnboardingClientProps {
  initialData: {
    profile: any;
    languages: any[];
    history: any[];
    areas: string[];
    levels: string[];
  };
}

export default function OnboardingClient({ initialData }: OnboardingClientProps) {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [savingState, setSavingState] = useState<"idle" | "saving" | "saved">("idle");
  const autosaveTimerRef = useRef<NodeJS.Timeout | null>(null);

  const {
    register,
    control,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm({
    defaultValues: {
      full_name: initialData.profile.full_name || "",
      headline: initialData.profile.headline || "",
      location: initialData.profile.location || "",
      visibility: initialData.profile.visibility || "public",
      bio: initialData.profile.bio || "",
      availability: initialData.profile.availability || "",
      linkedin_url: initialData.profile.linkedin_url || "",
      terms_accepted: false as boolean,
      privacy_accepted: false as boolean,
      languages:
        initialData.languages.length > 0
          ? initialData.languages
          : [{ language: "", level: "Nativo" }],
      history:
        initialData.history.length > 0
          ? initialData.history
          : [{ institution: "", role: "", from: "", to: "" }],
      faculty_areas: initialData.areas || [],
      levels: initialData.levels || [],
      modalities: initialData.profile.modalities || [],
      degrees: initialData.profile.degrees?.length > 0 ? initialData.profile.degrees : [""],
    },
  });

  const { fields: languageFields, append: appendLanguage, remove: removeLanguage } = useFieldArray({ control, name: "languages" });
  const { fields: historyFields, append: appendHistory, remove: removeHistory } = useFieldArray({ control, name: "history" });
  const { fields: degreeFields, append: appendDegree, remove: removeDegree } = useFieldArray({ control, name: "degrees" as any });

  const selectedAreas = watch("faculty_areas");
  const selectedModalities = watch("modalities");

  // Resume Logic: Skip to step 2 if step 1 essentials are filled
  useEffect(() => {
    const isStep1Complete =
      initialData.profile.headline &&
      initialData.profile.location &&
      initialData.languages.length > 0;
    if (isStep1Complete) setStep(2);
  }, []);

  // Build FormData from current values
  const buildFormData = useCallback((data: any) => {
    const fd = new FormData();
    Object.entries(data).forEach(([key, value]) => {
      if (key === "languages" || key === "history") {
        fd.append(key, JSON.stringify(value));
      } else if (Array.isArray(value)) {
        (value as any[]).forEach((v) => fd.append(key, v));
      } else if (typeof value === "boolean") {
        if (value) fd.append(key, "on");
      } else {
        fd.append(key, value as string);
      }
    });
    return fd;
  }, []);

  // Autosave — subscribe to form changes, skip initial mount
  const mountedRef = useRef(false);
  const lastSavedRef = useRef<string>("");
  useEffect(() => {
    const subscription = watch((data) => {
      if (!mountedRef.current) {
        mountedRef.current = true;
        lastSavedRef.current = JSON.stringify(data);
        return;
      }
      const serialized = JSON.stringify(data);
      if (serialized === lastSavedRef.current) return;

      if (autosaveTimerRef.current) clearTimeout(autosaveTimerRef.current);

      autosaveTimerRef.current = setTimeout(async () => {
        lastSavedRef.current = serialized;
        setSavingState("saving");
        const fd = buildFormData(data);
          const result = await autosaveOnboarding(fd);
          if (result?.success) {
            setSavingState("saved");
            setTimeout(() => setSavingState("idle"), 2000);
          } else {
            setSavingState("idle");
          }
      }, 2500);
    });
    return () => {
      subscription.unsubscribe();
      if (autosaveTimerRef.current) clearTimeout(autosaveTimerRef.current);
    };
  }, [watch, buildFormData]);

  const onSubmit = async (data: any) => {
    if (step === 1) {
      setStep(2);
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }

    setLoading(true);
    const fd = buildFormData(data);
    const result = await saveOnboarding(fd);

    if (result?.error) {
        toast.error(result.error);
        setLoading(false);
      } else {
        toast.success("¡Perfil completado con éxito!");
        window.location.href = "/app/faculty";
      }
  };

  const toggleArea = (area: string) => {
    const current = [...selectedAreas];
    const index = current.indexOf(area);
    if (index > -1) current.splice(index, 1);
    else current.push(area);
    setValue("faculty_areas", current);
  };

  const toggleModality = (mod: string) => {
    const current = [...selectedModalities];
    const index = current.indexOf(mod);
    if (index > -1) current.splice(index, 1);
    else current.push(mod);
    setValue("modalities", current);
  };

  const progress = step === 1 ? 50 : 100;

  return (
    <div className="min-h-screen bg-[#F2F6FC] flex flex-col font-sans">
      {/* Top Navigation & Progress */}
      <header className="bg-white border-b border-[#E2E8F0] py-4 px-6 lg:px-12 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-6">
          <Logo />

          <div className="flex flex-col items-center gap-1.5 flex-1 max-w-sm">
            <div className="flex justify-between w-full text-[10px] font-black uppercase tracking-widest text-gray-400">
              <span>Paso {step}/2</span>
              <span>{progress}%</span>
            </div>
            <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-[#1B4FD8]"
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.5, ease: "circOut" }}
              />
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {savingState === "saving" && (
              <span className="text-[10px] font-bold text-gray-400 flex items-center gap-1.5">
                <Loader2 size={10} className="animate-spin" />
                Guardando
              </span>
            )}
            {savingState === "saved" && (
              <span className="text-[10px] font-bold text-green-500 flex items-center gap-1.5">
                <CheckCircle2 size={10} />
                Guardado
              </span>
            )}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => { window.location.href = "/app/faculty"; }}
                className="text-gray-400 font-bold text-xs hover:text-[#0D2240]"
              >
                Saltar
              </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 flex flex-col items-center py-12 px-6 pb-32">
        <div className="max-w-2xl w-full">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-12">
            <AnimatePresence mode="wait">
              {step === 1 ? (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-10"
                >
                  <div className="space-y-3">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-100 text-[#1B4FD8] text-[10px] font-black uppercase tracking-widest">
                      <Sparkles size={12} />
                      Primeros Pasos
                    </div>
                    <h1 className="text-4xl font-black text-[#0D2240] tracking-tight leading-tight">
                      Configura tu perfil <span className="text-[#1B4FD8]">profesional</span>
                    </h1>
                    <p className="text-gray-500 font-medium text-lg">
                      Los campos marcados con * son imprescindibles.
                    </p>
                  </div>

                  <div className="grid gap-8">
                    {/* Basic Info */}
                    <div className="bg-white p-8 rounded-[32px] border border-gray-100 shadow-sm space-y-6">
                      <div className="space-y-1.5">
                        <label className="text-xs font-black uppercase tracking-widest text-gray-400 ml-1 flex items-center gap-2">
                          <UserCircle size={14} className="text-[#1B4FD8]" />
                          Nombre Completo *
                        </label>
                        <input
                          {...register("full_name", { required: true })}
                          placeholder="Tu nombre y apellidos"
                          className="w-full px-5 py-4 rounded-2xl border border-gray-100 bg-gray-50/50 focus:bg-white focus:ring-4 focus:ring-[#1B4FD8]/10 focus:border-[#1B4FD8] outline-none transition-all font-bold text-[#0D2240]"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-xs font-black uppercase tracking-widest text-gray-400 ml-1 flex items-center gap-2">
                          <Target size={14} className="text-[#1B4FD8]" />
                          Titular Académico *
                        </label>
                        <input
                          {...register("headline", { required: true })}
                          placeholder="Ej: PhD en Inteligencia Artificial aplicada a Finanzas"
                          className="w-full px-5 py-4 rounded-2xl border border-gray-100 bg-gray-50/50 focus:bg-white focus:ring-4 focus:ring-[#1B4FD8]/10 focus:border-[#1B4FD8] outline-none transition-all font-bold text-[#0D2240]"
                        />
                      </div>

                      <div className="grid sm:grid-cols-2 gap-6">
                        <div className="space-y-1.5">
                          <label className="text-xs font-black uppercase tracking-widest text-gray-400 ml-1 flex items-center gap-2">
                            <MapPin size={14} className="text-[#1B4FD8]" />
                            Ubicación *
                          </label>
                          <input
                            {...register("location", { required: true })}
                            placeholder="Ej: Madrid, España"
                            className="w-full px-5 py-4 rounded-2xl border border-gray-100 bg-gray-50/50 focus:bg-white focus:ring-4 focus:ring-[#1B4FD8]/10 focus:border-[#1B4FD8] outline-none transition-all font-bold text-[#0D2240] text-sm"
                          />
                        </div>
                        <div className="space-y-1.5">
                          <label className="text-xs font-black uppercase tracking-widest text-gray-400 ml-1 flex items-center gap-2">
                            <Eye size={14} className="text-[#1B4FD8]" />
                            Visibilidad
                          </label>
                          <select
                            {...register("visibility")}
                            className="w-full px-5 py-4 rounded-2xl border border-gray-100 bg-gray-50/50 focus:bg-white focus:ring-4 focus:ring-[#1B4FD8]/10 focus:border-[#1B4FD8] outline-none transition-all font-bold text-[#0D2240] text-sm appearance-none cursor-pointer"
                          >
                            <option value="public">Público</option>
                            <option value="hidden">Privado</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* GDPR */}
                    <div className="space-y-4 p-6 bg-white border border-gray-100 rounded-[24px] shadow-sm">
                      <label className="flex items-start gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          {...register("terms_accepted", { required: true })}
                          className="mt-0.5 w-4 h-4 rounded border-gray-300 text-[#1B4FD8] focus:ring-[#1B4FD8] cursor-pointer"
                        />
                        <span className="text-xs font-medium text-gray-500 leading-tight">
                          Acepto los{" "}
                          <Link href="/terms" className="text-[#1B4FD8] hover:underline font-bold">
                            Términos y Condiciones
                          </Link>{" "}
                          *
                        </span>
                      </label>
                      <label className="flex items-start gap-3 cursor-pointer">
                        <input
                          type="checkbox"
                          {...register("privacy_accepted", { required: true })}
                          className="mt-0.5 w-4 h-4 rounded border-gray-300 text-[#1B4FD8] focus:ring-[#1B4FD8] cursor-pointer"
                        />
                        <span className="text-xs font-medium text-gray-500 leading-tight">
                          Acepto la{" "}
                          <Link href="/privacy" className="text-[#1B4FD8] hover:underline font-bold">
                            Política de Privacidad
                          </Link>{" "}
                          (GDPR) *
                        </span>
                      </label>
                    </div>

                    {/* Languages */}
                    <div className="space-y-4">
                      <div className="flex items-center justify-between px-2">
                        <label className="text-xs font-black uppercase tracking-widest text-gray-400 flex items-center gap-2">
                          <Languages size={14} className="text-[#1B4FD8]" />
                          Idiomas *
                        </label>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => appendLanguage({ language: "", level: "Nativo" })}
                          className="text-[#1B4FD8] font-black text-[10px] uppercase tracking-tighter hover:bg-blue-50 rounded-full h-8"
                        >
                          <Plus size={14} className="mr-1" /> Añadir otro
                        </Button>
                      </div>
                      <div className="space-y-3">
                        {languageFields.map((field, idx) => (
                          <motion.div
                            layout
                            key={field.id}
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="flex gap-3 items-center bg-white p-3 rounded-2xl border border-gray-100 shadow-sm"
                          >
                            <select
                              {...register(`languages.${idx}.language` as const, { required: true })}
                              className="flex-1 px-4 py-2.5 rounded-xl border-none bg-gray-50/50 focus:bg-white focus:ring-2 focus:ring-[#1B4FD8] outline-none font-bold text-[#0D2240] text-sm appearance-none cursor-pointer"
                            >
                              <option value="">Idioma...</option>
                              {LANGUAGES_OPTIONS.map((l) => (
                                <option key={l.value} value={l.label}>{l.label}</option>
                              ))}
                            </select>
                            <select
                              {...register(`languages.${idx}.level` as const)}
                              className="w-32 px-4 py-2.5 rounded-xl border-none bg-gray-50/50 focus:bg-white focus:ring-2 focus:ring-[#1B4FD8] outline-none font-bold text-[#0D2240] text-sm appearance-none cursor-pointer text-center"
                            >
                              <option value="Nativo">Nativo</option>
                              <option value="C2">C2</option>
                              <option value="C1">C1</option>
                              <option value="B2">B2</option>
                              <option value="B1">B1</option>
                            </select>
                            {languageFields.length > 1 && (
                              <button
                                type="button"
                                onClick={() => removeLanguage(idx)}
                                className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                              >
                                <Trash2 size={18} />
                              </button>
                            )}
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-10"
                >
                  <div className="space-y-3">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-100 text-[#1B4FD8] text-[10px] font-black uppercase tracking-widest">
                      <Sparkles size={12} />
                      Perfil Enriquecido
                    </div>
                    <h1 className="text-4xl font-black text-[#0D2240] tracking-tight leading-tight">
                      Tu <span className="text-[#1B4FD8]">experiencia</span> marca la diferencia
                    </h1>
                    <p className="text-gray-500 font-medium text-lg">
                      Esta información es opcional pero ayuda a las instituciones a encontrarte.
                    </p>
                  </div>

                  <div className="grid gap-10">
                    {/* Bio */}
                    <div className="space-y-3">
                      <label className="text-xs font-black uppercase tracking-widest text-gray-400 ml-1 flex items-center gap-2">
                        <FileText size={14} className="text-[#1B4FD8]" />
                        Biografía Profesional
                      </label>
                      <textarea
                        {...register("bio")}
                        rows={5}
                        placeholder="Resume tu trayectoria académica y logros..."
                        className="w-full px-6 py-5 rounded-[24px] border border-gray-100 bg-white focus:ring-4 focus:ring-[#1B4FD8]/10 focus:border-[#1B4FD8] outline-none transition-all font-medium text-[#0D2240] resize-none leading-relaxed shadow-sm"
                      />
                    </div>

                    <div className="grid sm:grid-cols-2 gap-8">
                      <div className="space-y-1.5">
                        <label className="text-xs font-black uppercase tracking-widest text-gray-400 ml-1 flex items-center gap-2">
                          <Linkedin size={14} className="text-[#1B4FD8]" />
                          LinkedIn URL
                        </label>
                        <input
                          {...register("linkedin_url")}
                          placeholder="https://linkedin.com/in/..."
                          className="w-full px-5 py-4 rounded-2xl border border-gray-100 bg-white focus:ring-4 focus:ring-[#1B4FD8]/10 focus:border-[#1B4FD8] outline-none transition-all font-bold text-[#0D2240] text-sm shadow-sm"
                        />
                      </div>
                      <div className="space-y-1.5">
                        <label className="text-xs font-black uppercase tracking-widest text-gray-400 ml-1 flex items-center gap-2">
                          <Globe size={14} className="text-[#1B4FD8]" />
                          Disponibilidad
                        </label>
                        <input
                          {...register("availability")}
                          placeholder="Ej: Inmediata, Tardes..."
                          className="w-full px-5 py-4 rounded-2xl border border-gray-100 bg-white focus:ring-4 focus:ring-[#1B4FD8]/10 focus:border-[#1B4FD8] outline-none transition-all font-bold text-[#0D2240] text-sm shadow-sm"
                        />
                      </div>
                    </div>

                    {/* Modalities */}
                    <div className="space-y-4">
                      <label className="text-xs font-black uppercase tracking-widest text-gray-400 ml-1 flex items-center gap-2">
                        <MapPin size={14} className="text-[#1B4FD8]" />
                        Modalidades
                      </label>
                      <div className="flex flex-wrap gap-3">
                        {MODALITIES.map((mod) => (
                          <button
                            key={mod.id}
                            type="button"
                            onClick={() => toggleModality(mod.id)}
                            className={`px-6 py-3 rounded-2xl text-sm font-black transition-all border-2 ${
                              selectedModalities.includes(mod.id)
                                ? "bg-[#1B4FD8] border-[#1B4FD8] text-white shadow-lg shadow-blue-200"
                                : "bg-white border-gray-100 text-gray-400 hover:border-[#1B4FD8] hover:text-[#1B4FD8]"
                            }`}
                          >
                            {mod.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Areas */}
                    <div className="space-y-4">
                      <label className="text-xs font-black uppercase tracking-widest text-gray-400 ml-1 flex items-center gap-2">
                        <Target size={14} className="text-[#1B4FD8]" />
                        Áreas de Especialidad
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {AREAS.map((area) => (
                          <label
                            key={area}
                            onClick={() => toggleArea(area)}
                            className={`flex items-center gap-4 p-4 border-2 rounded-2xl cursor-pointer transition-all group ${
                              selectedAreas.includes(area)
                                ? "border-[#1B4FD8] bg-blue-50/50"
                                : "bg-white border-gray-100 hover:border-[#1B4FD8]"
                            }`}
                          >
                            <div
                              className={`w-5 h-5 rounded-lg border-2 flex items-center justify-center transition-all ${
                                selectedAreas.includes(area)
                                  ? "bg-[#1B4FD8] border-[#1B4FD8] text-white"
                                  : "border-gray-200 group-hover:border-[#1B4FD8]"
                              }`}
                            >
                              {selectedAreas.includes(area) && <CheckCircle2 size={12} />}
                            </div>
                            <span
                              className={`font-bold transition-colors text-sm ${
                                selectedAreas.includes(area)
                                  ? "text-[#1B4FD8]"
                                  : "text-[#0D2240] group-hover:text-[#1B4FD8]"
                              }`}
                            >
                              {area}
                            </span>
                          </label>
                        ))}
                      </div>
                    </div>

                    {/* Degrees */}
                    <div className="space-y-6">
                      <div className="flex items-center justify-between px-2">
                        <label className="text-xs font-black uppercase tracking-widest text-gray-400 flex items-center gap-2">
                          <GraduationCap size={14} className="text-[#1B4FD8]" />
                          Titulaciones Académicas
                        </label>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => appendDegree("")}
                          className="text-[#1B4FD8] font-black text-[10px] uppercase tracking-tighter hover:bg-blue-50 rounded-full h-8"
                        >
                          <Plus size={14} className="mr-1" /> Añadir otra
                        </Button>
                      </div>
                      <div className="space-y-3">
                        {degreeFields.map((field, idx) => (
                          <motion.div
                            layout
                            key={field.id}
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="flex gap-3 items-center bg-white p-3 rounded-2xl border border-gray-100 shadow-sm"
                          >
                            <input
                              {...register(`degrees.${idx}` as any)}
                              placeholder="Ej: PhD en Inteligencia Artificial (MIT)"
                              className="flex-1 px-4 py-2.5 rounded-xl border-none bg-gray-50/50 focus:bg-white focus:ring-2 focus:ring-[#1B4FD8] outline-none font-bold text-[#0D2240] text-sm"
                            />
                            {degreeFields.length > 1 && (
                              <button
                                type="button"
                                onClick={() => removeDegree(idx)}
                                className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                              >
                                <Trash2 size={18} />
                              </button>
                            )}
                          </motion.div>
                        ))}
                      </div>
                    </div>

                    {/* Teaching History */}
                    <div className="space-y-6">
                      <div className="flex items-center justify-between px-2">
                        <label className="text-xs font-black uppercase tracking-widest text-gray-400 flex items-center gap-2">
                          <History size={14} className="text-[#1B4FD8]" />
                          Historial Docente
                        </label>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => appendHistory({ institution: "", role: "", from: "", to: "" })}
                          className="text-[#1B4FD8] font-black text-[10px] uppercase tracking-tighter hover:bg-blue-50 rounded-full h-8"
                        >
                          <Plus size={14} className="mr-1" /> Añadir institución
                        </Button>
                      </div>
                      <div className="space-y-4">
                        {historyFields.map((field, idx) => (
                          <motion.div
                            layout
                            key={field.id}
                            className="p-6 bg-white border border-gray-100 rounded-[24px] shadow-sm space-y-4 relative group"
                          >
                            {historyFields.length > 1 && (
                              <button
                                type="button"
                                onClick={() => removeHistory(idx)}
                                className="absolute top-4 right-4 p-2 text-gray-200 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
                              >
                                <Trash2 size={18} />
                              </button>
                            )}
                            <div className="grid sm:grid-cols-2 gap-4">
                              <div className="space-y-1">
                                <span className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-1">Institución</span>
                                <input
                                  {...register(`history.${idx}.institution` as const)}
                                  placeholder="Nombre de la universidad"
                                  className="w-full px-4 py-2.5 rounded-xl border-none bg-gray-50/50 focus:bg-white focus:ring-2 focus:ring-[#1B4FD8] outline-none font-bold text-[#0D2240] text-sm"
                                />
                              </div>
                              <div className="space-y-1">
                                <span className="text-[10px] font-black uppercase tracking-widest text-gray-400 ml-1">Rol</span>
                                <input
                                  {...register(`history.${idx}.role` as const)}
                                  placeholder="Ej: Profesor Titular"
                                  className="w-full px-4 py-2.5 rounded-xl border-none bg-gray-50/50 focus:bg-white focus:ring-2 focus:ring-[#1B4FD8] outline-none font-bold text-[#0D2240] text-sm"
                                />
                              </div>
                            </div>
                            <div className="flex gap-4 items-center max-w-xs">
                              <input
                                type="number"
                                {...register(`history.${idx}.from` as const)}
                                placeholder="Desde"
                                className="w-full px-4 py-2.5 rounded-xl border-none bg-gray-50/50 focus:bg-white focus:ring-2 focus:ring-[#1B4FD8] outline-none font-bold text-[#0D2240] text-sm text-center"
                              />
                              <span className="text-gray-300 font-bold">—</span>
                              <input
                                type="number"
                                {...register(`history.${idx}.to` as const)}
                                placeholder="Hasta"
                                className="w-full px-4 py-2.5 rounded-xl border-none bg-gray-50/50 focus:bg-white focus:ring-2 focus:ring-[#1B4FD8] outline-none font-bold text-[#0D2240] text-sm text-center"
                              />
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </form>
        </div>
      </main>

      {/* Fixed bottom navigation — outside form to avoid z-index issues */}
      <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-sm border-t border-gray-100 px-6 py-4 z-40">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <Button
            type="button"
            variant="ghost"
            onClick={() => setStep(1)}
            disabled={step === 1 || loading}
            className="font-black text-gray-400 hover:text-[#0D2240] disabled:opacity-0 transition-all flex items-center gap-2 px-6 h-12 rounded-2xl"
          >
            <ArrowLeft size={18} />
            Atrás
          </Button>

          <div className="flex items-center gap-4">
            <p className="text-xs text-gray-400 font-medium hidden sm:block">
              {step === 1
                ? "Casi listo para continuar..."
                : "Tu perfil será visible para instituciones verificadas."}
            </p>
            <Button
              type="button"
              onClick={handleSubmit(onSubmit)}
              disabled={loading}
              className="bg-[#1B4FD8] hover:bg-[#0D2240] text-white px-10 h-14 rounded-[20px] font-black text-base shadow-xl shadow-blue-200 flex items-center gap-3 group transition-all"
            >
              {loading ? (
                <Loader2 size={20} className="animate-spin" />
              ) : (
                <>
                  {step === 1 ? "Continuar" : "Finalizar Perfil"}
                  <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
